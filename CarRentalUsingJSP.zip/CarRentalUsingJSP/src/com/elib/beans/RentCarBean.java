package com.elib.beans;

import java.sql.Date;

public class RentCarBean {
	private String carno, customerid, customername;
	private long customermobile;
	private Date renteddate;
	private String returnstatus;

	public RentCarBean() {
	}

	public RentCarBean(String carno, String customerid, String customername, long customermobile) {
		super();
		this.carno = carno;
		this.customerid = customerid;
		this.customername = customername;
		this.customermobile = customermobile;
	}

	public String getReturnstatus() {
		return returnstatus;
	}

	public void setReturnstatus(String returnstatus) {
		this.returnstatus = returnstatus;
	}

	public Date getRentedDate() {
		return renteddate;
	}

	public void setRentedDate(Date renteddate) {
		this.renteddate = renteddate;
	}

	public String getCarNo() {
		return carno;
	}

	public void setCarNo(String callno) {
		this.carno = callno;
	}

	public String getCustomerid() {
		return customerid;
	}

	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public long getCustomermobile() {
		return customermobile;
	}

	public void setCustomermobile(long customermobile) {
		this.customermobile = customermobile;
	}

}
