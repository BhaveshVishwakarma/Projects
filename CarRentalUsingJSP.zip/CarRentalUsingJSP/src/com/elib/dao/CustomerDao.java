package com.elib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.elib.DB.JDBCConnection;
import com.elib.beans.CustomerBean;

public class CustomerDao {

	public static int save(CustomerBean bean){
		int status=0;
		try{
			Connection con= JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("insert into CUSTOMER (name,email,password,mobile) values(?,?,?,?)");
			ps.setString(1,bean.getName());
			ps.setString(2,bean.getEmail());
			ps.setString(3,bean.getPassword());
			ps.setLong(4,bean.getMobile());
			status=ps.executeUpdate();
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static int update(CustomerBean bean){
		int status=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("update CUSTOMER set name=?,email=?,password=?,mobile=? where id=?");
			ps.setString(1,bean.getName());
			ps.setString(2,bean.getEmail());
			ps.setString(3,bean.getPassword());
			ps.setLong(4,bean.getMobile());
			ps.setInt(5,bean.getId());
			status=ps.executeUpdate();
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	
	public static List<CustomerBean> view(){
		List<CustomerBean> list=new ArrayList<CustomerBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CUSTOMER");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				CustomerBean bean=new CustomerBean();
				bean.setId(rs.getInt("id"));
				bean.setName(rs.getString("name"));
				bean.setEmail(rs.getString("email"));
				bean.setPassword(rs.getString("password"));
				bean.setMobile(rs.getLong("mobile"));
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	
	public static CustomerBean viewById(int id){
		CustomerBean bean=new CustomerBean();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CUSTOMER where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				bean.setId(rs.getInt(1));
				bean.setName(rs.getString(2));
				bean.setPassword(rs.getString(3));
				bean.setEmail(rs.getString(4));
				bean.setMobile(rs.getLong(5));
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return bean;
	}
	
	
	
	public static int delete(int id){
		int status=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("delete from CUSTOMER where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}

	public static boolean authenticate(String email,String password){
		boolean status=false;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CUSTOMER where email=? and password=?");
			ps.setString(1,email);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				status=true;
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	
	public static int getId(String email,String password){
		int id=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select id from CUSTOMER where email=? and password=?");
			ps.setString(1,email);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				id=rs.getInt("id");
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return id;
	}
}
