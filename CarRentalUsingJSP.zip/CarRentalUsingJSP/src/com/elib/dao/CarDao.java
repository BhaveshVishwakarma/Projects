package com.elib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.elib.DB.JDBCConnection;
import com.elib.beans.CarBean;
import com.elib.beans.RentCarBean;
import com.elib.beans.CustomerBean;

public class CarDao {

	public static int save(CarBean bean){
		int status=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("insert into CAR_INFO values(?,?,?,?,?,?)");
			ps.setString(1,bean.getCarno());
			ps.setString(2,bean.getName());
			ps.setString(3,bean.getModel());
			ps.setInt(4,bean.getYear());
			ps.setInt(5,bean.getRentedPrice());
			ps.setInt(6,0);
			status=ps.executeUpdate();
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	
	public static List<CarBean> view(){
		List<CarBean> list=new ArrayList<CarBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CAR_INFO");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				CarBean bean=new CarBean();
				bean.setCarno(rs.getString("carno"));
				bean.setName(rs.getString("company_name"));
				bean.setModel(rs.getString("model"));
				bean.setYear(rs.getInt("year"));
				bean.setRentedPrice(rs.getInt("rent_price"));
				bean.setRented(rs.getInt("rented"));
				
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	
	public static List<CarBean> searchCarByName(String name){
		List<CarBean> list=new ArrayList<CarBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CAR_INFO WHERE company_name LIKE ?");
			ps.setString(1, name+"%");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				CarBean bean=new CarBean();
				bean.setCarno(rs.getString("carno"));
				bean.setName(rs.getString("company_name"));
				bean.setModel(rs.getString("model"));
				bean.setYear(rs.getInt("year"));
				bean.setRentedPrice(rs.getInt("rent_price"));
				bean.setRented(rs.getInt("rented"));
				
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	
	public static List<CarBean> viewAvailableCars(){
		List<CarBean> list=new ArrayList<CarBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CAR_INFO where rented=?");
			ps.setInt(1,0);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				CarBean bean=new CarBean();
				bean.setCarno(rs.getString("carno"));
				bean.setName(rs.getString("company_name"));
				bean.setModel(rs.getString("model"));
				bean.setYear(rs.getInt("year"));
				bean.setRentedPrice(rs.getInt("rent_price"));
				bean.setRented(rs.getInt("rented"));
				
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	
	public static List<CarBean> searchByRentCarName(String name){
		List<CarBean> list=new ArrayList<CarBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CAR_INFO where rented=? AND company_name LIKE ?");
			ps.setInt(1,0);
			ps.setString(2,name +"%");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				CarBean bean=new CarBean();
				bean.setCarno(rs.getString("carno"));
				bean.setName(rs.getString("company_name"));
				bean.setModel(rs.getString("model"));
				bean.setYear(rs.getInt("year"));
				bean.setRentedPrice(rs.getInt("rent_price"));
				bean.setRented(rs.getInt("rented"));
				
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	
	public static int delete(String carno){

		int status=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("delete from CAR_INFO where carno=?");
			ps.setString(1,carno);
			status=ps.executeUpdate();
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	
	public static int getRented(String carno){
		int issued=0;
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from CAR_INFO where carno=?");
			ps.setString(1,carno);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				issued=rs.getInt("rented");
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return issued;
	}
	
	public static int rentCar(RentCarBean bean){
		String callno=bean.getCarNo();
		int checkstatus=getRented(callno);
		System.out.println("Check status: "+checkstatus);
		if(checkstatus==0){
			int status=0;
			try{
				Connection con=JDBCConnection.openConnection();
				PreparedStatement ps=con.prepareStatement("insert into RENT_CAR values(?,?,?,?,?,?)");
				ps.setString(1,bean.getCarNo());
				ps.setString(2,bean.getCustomerid());
				ps.setString(3,bean.getCustomername());
				ps.setLong(4,bean.getCustomermobile());
				java.sql.Date currentDate=new java.sql.Date(System.currentTimeMillis());
				ps.setDate(5,currentDate);
				ps.setString(6,"no");
				
				status=ps.executeUpdate();
				if(status>0){
					PreparedStatement ps2=con.prepareStatement("update CAR_INFO set rented=? where carno=?");
					ps2.setInt(1,1);
					ps2.setString(2,callno);
					status=ps2.executeUpdate();
				}
				JDBCConnection.closeConnection();
				
			}catch(Exception e){System.out.println(e);}
			
			return status;
		}else{
			return 0;
		}
	}
	public static int returnCar(String carno,int customerid){
		int status=0;
			try{
				Connection con=JDBCConnection.openConnection();
				PreparedStatement ps=con.prepareStatement("update RENT_CAR set RETURNSTATUS='yes' where carno=? and customerid=?");
				ps.setString(1,carno);
				ps.setInt(2,customerid);
				
				status=ps.executeUpdate();
				if(status>0){
					PreparedStatement ps2=con.prepareStatement("update CAR_INFO set rented=? where carno=?");
					ps2.setInt(1,0);
					ps2.setString(2,carno);
					status=ps2.executeUpdate();
				}
				JDBCConnection.closeConnection();
				
			}catch(Exception e){System.out.println(e);}
			
			return status;
	}
	public static List<RentCarBean> viewRentedCars(){
		List<RentCarBean> list=new ArrayList<RentCarBean>();
		try{
			Connection con=JDBCConnection.openConnection();
			PreparedStatement ps=con.prepareStatement("select * from RENT_CAR WHERE RETURNSTATUS=? order by RENTEDDATE desc");
			ps.setString(1, "no");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				RentCarBean bean=new RentCarBean();
				bean.setCarNo(rs.getString("carno"));
				bean.setCustomerid(rs.getString("customerid"));
				bean.setCustomername(rs.getString("customername"));
				bean.setCustomermobile(rs.getLong("customermobile"));
				bean.setRentedDate(rs.getDate("renteddate"));
				bean.setReturnstatus(rs.getString("returnstatus"));
				list.add(bean);
			}
			JDBCConnection.closeConnection();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
}