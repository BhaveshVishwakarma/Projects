package com.elib.DB;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConnection {
	static Connection con = null;
	
	public static Connection openConnection() {
		try {
			JDBCProperty.loadProperties();
			Class.forName(JDBCProperty.driverClass);
//			System.out.println("Driver Loaded...");
			con = DriverManager.getConnection(JDBCProperty.url, JDBCProperty.username, JDBCProperty.password);
//			System.out.println("Connection Established...");			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return con;
	}
	
	public static void closeConnection() {
		try {
			if(con!=null) {
				con.close();
//				System.out.println("Connection closed...");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}