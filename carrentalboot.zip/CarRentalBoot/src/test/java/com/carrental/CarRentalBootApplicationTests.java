package com.carrental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
